<link rel="stylesheet" href="{{asset('css/core.css')}}">
<link rel="stylesheet" href="{{asset('css/fontawesome.css')}}">

