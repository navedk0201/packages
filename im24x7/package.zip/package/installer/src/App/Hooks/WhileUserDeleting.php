<?php

namespace Gainhq\Installer\App\Hooks;

use Gainhq\Installer\App\Helpers\Traits\InstanceCreator;


class WhileUserDeleting extends HookContract
{
    use InstanceCreator;

    public function handle()
    {
        // TODO: Implement handle() method.
    }
}