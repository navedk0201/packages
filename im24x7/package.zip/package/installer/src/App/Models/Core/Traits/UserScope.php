<?php

namespace Gainhq\Installer\App\Models\Core\Traits;

use Illuminate\Database\Eloquent\Builder;

/**
 * Class UserScope.
 */
trait UserScope
{

}
